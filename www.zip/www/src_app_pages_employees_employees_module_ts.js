(self["webpackChunkform"] = self["webpackChunkform"] || []).push([["src_app_pages_employees_employees_module_ts"],{

/***/ 5899:
/*!*************************************************************!*\
  !*** ./src/app/pages/employees/employees-routing.module.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeesPageRoutingModule": () => (/* binding */ EmployeesPageRoutingModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 9895);
/* harmony import */ var _employees_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employees.page */ 4866);




const routes = [
    {
        path: '',
        component: _employees_page__WEBPACK_IMPORTED_MODULE_0__.EmployeesPage
    },
    {
        path: 'edit',
        loadChildren: () => __webpack_require__.e(/*! import() */ "common").then(__webpack_require__.bind(__webpack_require__, /*! ./edit/edit.module */ 7155)).then(m => m.EditPageModule)
    }
];
let EmployeesPageRoutingModule = class EmployeesPageRoutingModule {
};
EmployeesPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], EmployeesPageRoutingModule);



/***/ }),

/***/ 132:
/*!*****************************************************!*\
  !*** ./src/app/pages/employees/employees.module.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeesPageModule": () => (/* binding */ EmployeesPageModule)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 8583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 476);
/* harmony import */ var _employees_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./employees-routing.module */ 5899);
/* harmony import */ var _employees_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./employees.page */ 4866);







let EmployeesPageModule = class EmployeesPageModule {
};
EmployeesPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _employees_routing_module__WEBPACK_IMPORTED_MODULE_0__.EmployeesPageRoutingModule
        ],
        declarations: [_employees_page__WEBPACK_IMPORTED_MODULE_1__.EmployeesPage]
    })
], EmployeesPageModule);



/***/ }),

/***/ 4866:
/*!***************************************************!*\
  !*** ./src/app/pages/employees/employees.page.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "EmployeesPage": () => (/* binding */ EmployeesPage)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 4762);
/* harmony import */ var _raw_loader_employees_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./employees.page.html */ 4744);
/* harmony import */ var _employees_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./employees.page.scss */ 6251);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/core */ 7716);
/* harmony import */ var src_app_services_employee_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/services/employee.service */ 4416);





let EmployeesPage = class EmployeesPage {
    constructor(data) {
        this.data = data;
    }
    ngOnInit() {
        this.employees = this.data.getData();
    }
    onDelete(id) {
        this.data.onDelete(id);
    }
};
EmployeesPage.ctorParameters = () => [
    { type: src_app_services_employee_service__WEBPACK_IMPORTED_MODULE_2__.EmployeeService }
];
EmployeesPage = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_4__.Component)({
        selector: 'app-employees',
        template: _raw_loader_employees_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_employees_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], EmployeesPage);



/***/ }),

/***/ 6251:
/*!*****************************************************!*\
  !*** ./src/app/pages/employees/employees.page.scss ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("ion-menu-button {\n  color: var(--ion-color-primary);\n}\n\n#container {\n  text-align: center;\n  position: absolute;\n  left: 0;\n  right: 0;\n  top: 50%;\n  transform: translateY(-50%);\n}\n\n#container strong {\n  font-size: 20px;\n  line-height: 26px;\n}\n\n#container p {\n  font-size: 16px;\n  line-height: 22px;\n  color: #8c8c8c;\n  margin: 0;\n}\n\n#container a {\n  text-decoration: none;\n}\n\ntable {\n  font-family: arial, sans-serif;\n  border-collapse: collapse;\n  width: 80%;\n}\n\ntd, th {\n  border: 1px solid #dddddd;\n  text-align: left;\n  padding: 8px;\n}\n\ntr:nth-child(even) {\n  background-color: #dddddd;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImVtcGxveWVlcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBVUE7RUFDSSwrQkFBQTtBQVRKOztBQVlFO0VBQ0Usa0JBQUE7RUFDQSxrQkFBQTtFQUNBLE9BQUE7RUFDQSxRQUFBO0VBQ0EsUUFBQTtFQUNBLDJCQUFBO0FBVEo7O0FBWUU7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7QUFUSjs7QUFZRTtFQUNFLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGNBQUE7RUFDQSxTQUFBO0FBVEo7O0FBWUU7RUFDRSxxQkFBQTtBQVRKOztBQWFFO0VBQ0UsOEJBQUE7RUFDQSx5QkFBQTtFQUNBLFVBQUE7QUFWSjs7QUFhRTtFQUNFLHlCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0FBVko7O0FBYUU7RUFDRSx5QkFBQTtBQVZKIiwiZmlsZSI6ImVtcGxveWVlcy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxuXHJcblxyXG5cclxuaW9uLW1lbnUtYnV0dG9uIHtcclxuICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7XHJcbiAgfVxyXG4gIFxyXG4gICNjb250YWluZXIge1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgbGVmdDogMDtcclxuICAgIHJpZ2h0OiAwO1xyXG4gICAgdG9wOiA1MCU7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoLTUwJSk7XHJcbiAgfVxyXG4gIFxyXG4gICNjb250YWluZXIgc3Ryb25nIHtcclxuICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgIGxpbmUtaGVpZ2h0OiAyNnB4O1xyXG4gIH1cclxuICBcclxuICAjY29udGFpbmVyIHAge1xyXG4gICAgZm9udC1zaXplOiAxNnB4O1xyXG4gICAgbGluZS1oZWlnaHQ6IDIycHg7XHJcbiAgICBjb2xvcjogIzhjOGM4YztcclxuICAgIG1hcmdpbjogMDtcclxuICB9XHJcbiAgXHJcbiAgI2NvbnRhaW5lciBhIHtcclxuICAgIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcclxuICB9XHJcbiAgXHJcbiAgXHJcbiAgdGFibGUge1xyXG4gICAgZm9udC1mYW1pbHk6IGFyaWFsLCBzYW5zLXNlcmlmO1xyXG4gICAgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcclxuICAgIHdpZHRoOiA4MCU7XHJcbiAgfVxyXG4gIFxyXG4gIHRkLCB0aCB7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjZGRkZGRkO1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIHBhZGRpbmc6IDhweDtcclxuICB9XHJcbiAgXHJcbiAgdHI6bnRoLWNoaWxkKGV2ZW4pIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNkZGRkZGQ7XHJcbiAgfVxyXG4gIFxyXG4gIFxyXG4gIFxyXG4gIFxyXG4gIFxyXG4gICJdfQ== */");

/***/ }),

/***/ 4744:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/employees/employees.page.html ***!
  \*******************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("\n<div>\n\n  <a routerLink=\"/add/0\">Add</a>\n\n  <table  style=\"width:fit-content\">\n\n  <th>eName</th>\n  <th>eAddress </th>\n  <th>eEmail </th>\n  <th>eDOB </th>\n  <th>eGender </th>\n  <th>eDate_of_joining </th>\n  <th>eMartial_status </th>\n  <th>eContact </th>\n  <th></th>\n\n  <tbody>\n    <tr *ngFor=\"let emp of employees\">\n\n      <td>{{emp.eName}}</td>\n      <td>{{emp.eAddress}}</td>\n      <td>{{emp.eEmail}}</td>\n      <td>{{emp.eDOB}}</td>\n      <td>{{emp.eGender}}</td>\n      <td>{{emp.eDate_of_joining}}</td>\n      <td>{{emp.eMartial_status}}</td>\n      <td>{{emp.eContact}}</td>\n      <td><a [routerLink]=\"['/edit',employees.id]\">Edit</a></td>\n      <td><button (click)=\"onDelete(employees.id)\">x</button></td>\n\n\n    </tr>\n  </tbody>\n  </table>\n</div>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_pages_employees_employees_module_ts.js.map